<div class="container contact1-container h-100">
	<div class="d-flex flex-column h-100 justify-content-center">
		<div class=" ms-135px me-135px">
			<h2 class="fs-3r fw-bold text-decoration-underline text-secondary mb-5">LET'S BE PARTNERS IN SUCCESS!</h2>
			<div class="row">
				<div class="col-lg-6 d-flex flex-column justify-content-between">
					<div>
						<h4 class="h4-title">Main Office: The One Vietnam Co. Ltd,.</h4>
						<span class="small-red-span my-4"></span>
						<p>
							Address: 40 - 42 Thien Phuoc Street, Ward 10, Tan Binh District, Ho Chi Minh City, Vietnam
						</p>
						<div class="d-flex gap-2">
							<p>Phone:</p>
							<div>
								<p>(84) 902.111.222 - mobile</p>
								<p>(84)28.333.6688 - hot line</p>
								<p>(84)28.234.5678 - fax</p>
							</div>
						</div>
						<p>Email: loremipsum123@gmail.com</p>
						<p>Website: www.loremipsum.com</p>
					</div>
				</div>
				<div class="col-lg-6">
					<div class="mb-3">
						<h4 class="h4-title">Brand Office: The One Office Vietnam</h4>
						<span class="small-red-span my-4"></span>
						<p>
							Lorem ipsum dolor sit amet consectetur adipisicing elit. Quaerat laudantium praesentium illum quidemcorrupti iure aliquam, ipsa deleniti alias?
						</p>
						<div class="d-flex gap-2">
							<p>Phone:</p>
							<div>
								<p>(84) 902.111.222 - mobile</p>
								<p>(84)28.333.6688 - hot line</p>
								<p>(84)28.234.5678 - fax</p>
							</div>
						</div>
						<p>Email: loremipsum123@gmail.com</p>
						<p>Website: www.loremipsum.com</p>
					</div>
					<div class="position-relative">
						<span class="small-red-span my-4"></span>
						<p>
							Address: 40 - 42 Thien Phuoc Street, Ward 10, Tan Binh District, Ho Chi Minh City, Vietnam
						</p>
						<div class="d-flex gap-2">
							<p>Phone:</p>
							<div>
								<p>(84) 902.111.222 - mobile</p>
								<p>(84)28.333.6688 - hot line</p>
								<p>(84)28.234.5678 - fax</p>
							</div>
						</div>
						<p>Email: loremipsum123@gmail.com</p>
						<p>Website: www.loremipsum.com</p>
					</div>
				</div>
			</div>
			<div class="d-none d-lg-flex justify-content-between">
				<a role="button" class="slide-prev-btn position-absolute bottom-0 start-0 d-none d-md-flex">
					<img src="{{ asset('assets/images/arrow-left.svg') }}" alt="">
				</a>
				<a role="button" class="slide-next-btn position-absolute bottom-0 end-0 d-none d-md-flex" style="transform: rotate(180deg)">
					<img src="{{ asset('assets/images/arrow-left.svg') }}" alt="">
				</a>
			</div>
		</div>
	</div>
</div>

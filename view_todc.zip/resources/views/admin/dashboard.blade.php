@extends('layouts.admin')

@section('content')
	<div class="d-flex flex-column align-items-center justify-content-center pt-5r">
		<h2 class="fs-3r fw-bold text-secondary mt-3 mb-5">WELCOME TO ADMIN PAGE</h2>
		<img src="{{ asset('assets/images/admin_welcome.svg') }}" alt="">
	</div>
@endsection